#!/bin/bash

# This is my first script!

echo "Hello thre, $USER"
echo "Today is $(date)"
echo "last ran hi at $(date)" >> hi.log


